library(testthat)
library(uGMAR)

test_check("uGMAR")
